# nagoya-tv-hackathon

2024年9月14日メ～テレハッカソン

##### Pythonのインストール

`winget add python`

##### モジュールのインストール

`pip install numpy`

`pip install opencv-python`

##### ball-recognition.py

`python .\ball-recognition.py`
